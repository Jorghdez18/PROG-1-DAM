package com.docencia.repository.impl;

import java.util.HashSet;
import java.util.Set;

import com.docencia.model.Usuario;
import com.docencia.repository.IUserRepository;
import com.docencia.repository.file.FileCsv;
import com.docencia.util.Validaciones;

public class UserRepositoryImpl extends FileCsv implements IUserRepository {

    private final Set<Usuario> usuarios;

    public UserRepositoryImpl() {
        super();
        this.usuarios = super.read();
    }

    @Override
    public Usuario findByEmail(String email) {

        String emailNormalizado = Validaciones.normalizarEmail(email);

        if (emailNormalizado == null) {
            return null;
        }

        Usuario usuarioBuscar = new Usuario(emailNormalizado);

        for (Usuario usuario : usuarios) {
            if (usuario.equals(usuarioBuscar)) {
                return usuario;
            }
        }

        return null;
    }

    @Override
    public boolean existsByEmail(String email) {

        String emailNormalizado = Validaciones.normalizarEmail(email);

        if (emailNormalizado == null) {
            return false;
        }

        Usuario usuarioBuscar = new Usuario(emailNormalizado);

        return usuarios.contains(usuarioBuscar);
    }

    @Override
    public void save(Usuario usuario) {

        if (existsByEmail(usuario.getEmail())) {
            throw new IllegalArgumentException("Ya existe un usuario con ese email");
        }

        usuarios.add(usuario);
    }

    @Override
    public Set<Usuario> findAll() {
        return new HashSet<>(usuarios);
    }

    @Override
    public boolean deleteByEmail(String email) {

        Usuario usuario = findByEmail(email);

        if (usuario == null) {
            return false;
        }

        return usuarios.remove(usuario);
    }
}