package com.docencia.util;

import java.util.regex.Pattern;

public class Validaciones {

   

    /**
     * Normaliza el email: trim + lowercase
     */
    public static String normalizarEmail(String email) {
        if (email == null) {
            return null;
        }
        return email.trim().toLowerCase();
    }

    /**
     * Comprueba si el email es válido
     */
    public static boolean emailValido(String email) {

        String normalizado = normalizarEmail(email);

        if (normalizado == null) {
            return false;
        }

        String patron = "^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$";
        return Pattern.matches(patron, normalizado);
    }

    /**
     * Comprueba si la contraseña es válida
     */
    public static boolean passwordValida(String password) {
        if (password == null || password.length() < 6){
            return false;
        }
        return true;
    }

    /**
     * Lanza excepción si la contraseña no es válida
     */
    public static void validarPassword(String password) {

        if (!passwordValida(password)) {
            throw new IllegalArgumentException("La contraseña debe tener al menos 6 caracteres");
        }
    }

    /**
     * Valida el nombre de la persona
     */
    public static void validarNombre(String nombre) {
        
        if (nombre == null) {
            throw new IllegalArgumentException("El nombre no puede ser null");
        }

        if (nombre == null || nombre.trim().length() < 5) {
            throw new IllegalArgumentException("El nombre debe tener al menos 5 caracteres");
        }
    }

    /**
     * Valida el email
     */
    public static void validarEmail(String email) {

        if (!emailValido(email)) {
            throw new IllegalArgumentException("El email no tiene un formato válido");
        }
    }
}