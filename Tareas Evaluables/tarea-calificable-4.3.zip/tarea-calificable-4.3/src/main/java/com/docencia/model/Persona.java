package com.docencia.model;


import java.util.Objects;

public class Persona {

    protected final int id;
    protected String nombre;



    protected Persona(int id) {
        this.id = id;
    }

    protected Persona(int id, String nombre) {
        this.id= id;
        this.nombre = nombre;
    }

    public String getNombre() {
        return this.nombre;
    }

    public int getId(){
        return this.id;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }



    @Override
    public boolean equals(Object o) {
        if (o == null){
            return false;
        }
        if (o == this)
            return true;
        if (!(o instanceof Persona)) {
            return false;
        }
        Persona persona = (Persona) o;
        return id == persona.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "{" +
            " nombre='" + getNombre() + "'" +
            "}";
    }
    


}
