package com.docencia.service;

import com.docencia.model.Usuario;

public interface IAuthService {

  /**
   * Registra a un usuario nuevo
   * @param id id de la persona
   * @param nombre nombre de la persona
   * @param email email de la persona
   * @param password contraseña de la cuenta
   */
  Usuario register(int id, String nombre, String email, String password);

  /**
   * Logueo del usuario en la aplicacion
   * @param email emial del usuario
   * @param password 
   * @return
   */
  boolean login(String email, String password);

  /**
   * Comprueba que un usuario esta bloqueado
   * @param email email del usuario
   * @return retorna true si esta bloqueado
   */
  boolean isBloqueado(String email);

  /**
   * Desbloquea al usuario
   * @param email email del usuario
   */
  void desbloquear(String email);
}

