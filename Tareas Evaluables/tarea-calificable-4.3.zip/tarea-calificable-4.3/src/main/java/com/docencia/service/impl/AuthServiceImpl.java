package com.docencia.service.impl;

import com.docencia.model.Usuario;
import com.docencia.repository.IUserRepository;
import com.docencia.service.IAuthService;
import com.docencia.util.Validaciones;

public class AuthServiceImpl implements IAuthService {

    private final IUserRepository userRepository;

    public AuthServiceImpl(IUserRepository repo) {
        this.userRepository = repo;
    }

    @Override
    public Usuario register(int id, String nombre, String email, String password) {

        Validaciones.validarNombre(nombre);
        Validaciones.validarEmail(email);
        Validaciones.validarPassword(password);

        email = Validaciones.normalizarEmail(email);

        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("El usuario ya existe");
        }

        Usuario usuario = new Usuario(id, nombre, email, password);

        userRepository.save(usuario);

        return usuario;
    }

    @Override
    public boolean login(String email, String password) {

        if (!Validaciones.emailValido(email)) {
            return false;
        }

        email = Validaciones.normalizarEmail(email);

        Usuario usuario = userRepository.findByEmail(email);

        if (usuario == null) {
            return false;
        }
        if (usuario.isBloqueado()) {
            return false;
        }

        if (!usuario.getPassword().equals(password)) {

            usuario.incrementarIntentosFallidos();

            if (usuario.getIntentosFallidos() >= 3) {
                usuario.bloquear();
            }
            return false;
        }

        usuario.resetearIntentosFallidos();
        return true;
    }

    @Override
    public boolean isBloqueado(String email) {

        if (!Validaciones.emailValido(email)) {
            return false;
        }

        email = Validaciones.normalizarEmail(email);
        Usuario usuario = userRepository.findByEmail(email);

        if (usuario == null) {
            return false;
        }
        return usuario.isBloqueado();
    }

    @Override
    public void desbloquear(String email) {

        if (!Validaciones.emailValido(email)) {
            return;
        }

        email = Validaciones.normalizarEmail(email);
        Usuario usuario = userRepository.findByEmail(email);

        if (usuario != null) {
            usuario.resetearIntentosFallidos();
        }
    }
}