package com.docencia.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.docencia.model.Usuario;
import com.docencia.repository.IUserRepository;
import com.docencia.service.IUserService;
import com.docencia.util.Validaciones;

public class UserServiceImpl implements IUserService {

    private final IUserRepository userRepository;

    public UserServiceImpl(IUserRepository repo) {
        this.userRepository = repo;
    }

    @Override
    public Usuario crearUsuario(int id, String nombre, String email, String password) {

        Validaciones.validarNombre(nombre);
        Validaciones.validarEmail(email);
        Validaciones.validarPassword(password);

        email = Validaciones.normalizarEmail(email);

        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("El usuario ya existe");
        }

        Usuario usuario = new Usuario(id, nombre, email, password);

        userRepository.save(usuario);

        return usuario;
    }

    @Override
    public Set<Usuario> listarUsuarios() {
        return userRepository.findAll();
    }

    @Override
    public Usuario buscarPorEmail(String email) {

        Validaciones.validarEmail(email);

        email = Validaciones.normalizarEmail(email);

        return userRepository.findByEmail(email);
    }

    @Override
    public boolean eliminarPorEmail(String email) {

        Validaciones.validarEmail(email);
        email = Validaciones.normalizarEmail(email);
        return userRepository.deleteByEmail(email);
    }

    @Override
    public Usuario cambiarNombre(String email, String nuevoNombre) {

        Validaciones.validarEmail(email);
        Validaciones.validarNombre(nuevoNombre);

        email = Validaciones.normalizarEmail(email);
        Usuario usuario = userRepository.findByEmail(email);

        if (usuario == null) {
            return null;
        }

        usuario.setNombre(nuevoNombre.trim());
        return usuario;
    }

    @Override
    public Usuario cambiarPassword(String email, String nuevaPassword) {

        Validaciones.validarEmail(email);
        Validaciones.validarPassword(nuevaPassword);

        email = Validaciones.normalizarEmail(email);
        Usuario usuario = userRepository.findByEmail(email);

        if (usuario == null) {
            return null;
        }

        usuario.setPassword(nuevaPassword);
        return usuario;
    }

    @Override
    public Set<Usuario> obtenerBloqueados() {
        Set<Usuario> bloqueados = new HashSet();
        Set<Usuario> todos = userRepository.findAll();
        for (Usuario usuario : todos) {
            if (usuario.getBloqueado()){
                bloqueados.add(usuario);
            }
        }
        return bloqueados;
    }
}