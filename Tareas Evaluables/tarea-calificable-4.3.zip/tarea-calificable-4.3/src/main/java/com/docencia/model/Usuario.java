package com.docencia.model;

import java.time.LocalDate;
import java.util.Objects;
import com.docencia.util.Validaciones;

public class Usuario extends Persona {

    private final String email;
    private String password;
    private int intentosFallidos;
    private boolean bloqueado;
    private final LocalDate fechaRegistro;

    /**
     * Constructor de la clase
     * @param id identificador
     * @param nombre nombre
     * @param email email unico 
     * @param password passwords
     */
    public Usuario(int id, String email, String nombre, String password) {
        super(id, nombre);

        Validaciones.validarNombre(nombre);
        Validaciones.validarEmail(email);
        Validaciones.validarPassword(password);

        this.email = email.trim().toLowerCase();
        this.password = password;
        this.intentosFallidos = 0;
        this.bloqueado = false;
        this.fechaRegistro = LocalDate.now();
    }

    public Usuario(String email) {

         super(0, "temp");
        Validaciones.validarEmail(email);

        this.email = email.trim().toLowerCase();
        this.password = "";
        this.intentosFallidos = 0;
        this.bloqueado = false;
        this.fechaRegistro = LocalDate.now();
    }

    public String getEmail() {
        return this.email;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String nuevaPassword) {
        Validaciones.validarPassword(nuevaPassword);
        this.password = nuevaPassword;
    }

    public int getIntentosFallidos() {
        return this.intentosFallidos;
    }

    public boolean isBloqueado() {
        return this.bloqueado;
    }

    public void incrementarIntentosFallidos() {
        this.intentosFallidos++;
    }

    public void resetearIntentosFallidos() {
        this.intentosFallidos = 0;
    }

    public void bloquear() {
        this.bloqueado = true;
    }

    public LocalDate getFechaRegistro() {
        return this.fechaRegistro;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null){
            return false;
        }
        if (this == o)
            return true;
        if (!(o instanceof Usuario))
            return false;
        Usuario usuario = (Usuario) o;
        if (email == null || usuario.getEmail() == null){
            return false;
        }
        return Objects.equals(email, usuario.email);
        
    }

    @Override
    public int hashCode() {
        return Objects.hash(email);
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + getId() +
                ", nombre='" + getNombre() + '\'' +
                ", email='" + email + '\'' +
                ", intentosFallidos=" + intentosFallidos +
                ", bloqueado=" + bloqueado +
                ", fechaRegistro=" + fechaRegistro +
                '}';
    }
}
