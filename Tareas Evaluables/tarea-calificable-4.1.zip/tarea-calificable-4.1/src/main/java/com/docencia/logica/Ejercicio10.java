package com.docencia.logica;

public class Ejercicio10 {
  /**
   * Invierte cadena
   * TODO: Implementar usando lógica tradicional (iterativo).
   */
 public static String invertirCadena(String s) {
        if (s == null) {
          return null; 
        }
        String r = "";
        for (int i = s.length() - 1; i >= 0; i--) {
            r += s.charAt(i); 
        }

        return r;
    }
}
