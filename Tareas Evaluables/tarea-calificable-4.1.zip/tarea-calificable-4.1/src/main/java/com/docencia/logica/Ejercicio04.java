package com.docencia.logica;

public class Ejercicio04 {
  /**
   * Devuelve el n-ésimo Fibonacci
   * Fibonacci --> cada numero es la suma de los dos anteriores --> 0, 1, 1, 2, 3, 5, 8, ...
   */
 public static long fibonacci(int n) {
   if (n < 0) {
        throw new IllegalArgumentException();
    }
     if(n == 0){
      return 0;
    }
    if(n == 1){
      return 1;
    }

    long a =0; //F(0)
    long b = 1;//F(1)
    long resultado = 0;

    for (int i = 2; i <= n; i++) {
     resultado = a + b; //Secuencia de fibonacci: F(n) = F(n-1) + F(n-2)
        a = b;
        b = resultado;
    }
    return resultado;
  }
}
