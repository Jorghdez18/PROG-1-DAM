package com.docencia.logica;

public class Ejercicio22 {
  /**
   * Potencia rápida O(log exp)
   * TODO: Implementar usando lógica tradicional (iterativo).
   */
  public static long potenciaRapida(long base, int exponente) {
    if (exponente < 0) {
      throw new IllegalArgumentException();
    }

    long resultado = 1;
    long b = base;
    int e = exponente;

    while (e > 0) {
      if ((e & 1) == 1) {
        resultado *= b;
      }
      b *= b;
      e >>= 1;
    }

    return resultado;
  }
}