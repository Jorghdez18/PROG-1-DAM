package com.docencia.recursividad;

import java.util.Arrays;

public class Ejercicio13 {
  /**
   * Índice o -1
   * TODO: Implementar usando recursividad.
   */
  public static int buscarLineal(int[] arreglo, int objetivo) {
    if (arreglo == null) {
      return -1;
    }
     if (arreglo.length == 0) {
      return -1;
    }
     if (arreglo[0] == objetivo) {
      return 0;
    }

   int[] resto = Arrays.copyOfRange(arreglo, 1, arreglo.length);
    int resultado = buscarLineal(resto, objetivo);

    if (resultado == -1) {
      return -1;
    } else {
      return resultado + 1;
    }
  }
}
