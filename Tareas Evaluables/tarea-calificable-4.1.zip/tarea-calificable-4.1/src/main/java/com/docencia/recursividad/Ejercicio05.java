package com.docencia.recursividad;

public class Ejercicio05 {
  /**
   * MCD por Euclides --> El número entero positivo más grande que divide a ambos
   * sin dejar resto.
   * TODO: Implementar usando recursividad.
   */
  public static int mcd(int a, int b) {
    if (a < 0) {
      a = Math.abs(a);// convertimos a en positivo
    }
    if (b < 0) {
      b = Math.abs(b);// convertimos b en positivio
    }

    if (b == 0) {
      return a;
    }
    
    return mcd(b, a % b);
  }
}