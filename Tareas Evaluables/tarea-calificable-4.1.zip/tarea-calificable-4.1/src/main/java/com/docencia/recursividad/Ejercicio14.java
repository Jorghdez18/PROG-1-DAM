package com.docencia.recursividad;

public class Ejercicio14 {
  /**
   * ¿Es palíndromo?
   * TODO: Implementar usando recursividad.
   */
  public static boolean esPalindromo(String texto) {
    if (texto == null) return false;

    return pal(texto, 0, texto.length() - 1);
  }

  private static boolean pal(String s, int i, int j) {
   
    if (i >= j) return true;

    if (s.charAt(i) != s.charAt(j)) {
      return false; 
    }

    return pal(s, i + 1, j - 1);
  }
}
