package com.docencia.recursividad;

public class Ejercicio07 {
  /**
   * Suma de dígitos
   * TODO: Implementar usando recursividad.
   */
  public static int sumaDigitos(int n) {
     n = Math.abs(n); // aceptar negativos
   
    if (n < 10) {
        return n;
    }
    return n % 10 + sumaDigitos(n / 10);
}
}
