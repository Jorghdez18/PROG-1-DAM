package com.docencia.recursividad;

public class Ejercicio10 {
  /**
   * Invierte cadena
   * TODO: Implementar usando recursividad.
   */
   public static String invertirCadena(String s) {
        if (s == null) {
          return null;
        } 
        if (s.length() <= 1) {
          return s; 
        }

        return s.charAt(s.length() - 1) + invertirCadena(s.substring(0, s.length() - 1));
    }
}
