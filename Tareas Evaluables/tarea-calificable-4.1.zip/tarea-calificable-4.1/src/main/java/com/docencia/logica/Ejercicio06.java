package com.docencia.logica;

import java.util.*;

public class Ejercicio06 {
  /**
   * Devuelve [n, n-1, ..., 0]
   * TODO: Implementar usando lógica tradicional (iterativo).
   */
  public static List<Integer> cuentaRegresiva(int n) {
    if (n < 0) {
      throw new IllegalArgumentException();
    }

    List<Integer> resultado = new ArrayList<>();
    if (n == 0) {
      resultado.add(0);
      return resultado;
    }

    for (int i = 0; i <= n; i++) {
      resultado.add(n - i);
    }
    return resultado;
  }
}