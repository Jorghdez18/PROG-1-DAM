package com.docencia.recursividad;

public class Ejercicio16 {
  /**
   * Elimina c
   * TODO: Implementar usando recursividad.
   */
  public static String eliminarCaracter(String texto, char c) {
    if (texto == null) return "";

    if (texto.isEmpty()) {
      return "";
    }
   char ch = texto.charAt(0);
    String resto = eliminarCaracter(texto.substring(1), c);

    if (ch == c) {
      return resto;
    } else {
      return ch + resto;
    }
  }
}