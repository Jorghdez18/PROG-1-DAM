package com.docencia.recursividad;

public class Ejercicio12 {
  /**
   * Máximo elemento
   * TODO: Implementar usando recursividad.
   */
  public static int maximoArreglo(int[] arreglo) {
    if(arreglo == null){
      throw new IllegalArgumentException();
    }
    if (arreglo.length < 1){
      return 0;
    }
    return 0;
  }
}
