package com.docencia.recursividad;

public class Ejercicio17 {
  /**
   * ¿Ordenado asc?
   * TODO: Implementar usando recursividad.
   */
 public static boolean estaOrdenadoAsc(int[] arreglo) {
    if (arreglo == null) return true;

    if (arreglo.length <= 1) {
      return true; 
    }

    if (arreglo[0] > arreglo[1]) {
      return false;
    }
    
    int[] resto = java.util.Arrays.copyOfRange(arreglo, 1, arreglo.length);
    return estaOrdenadoAsc(resto);
  }
}
