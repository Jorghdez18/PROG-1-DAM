package com.docencia.recursividad;

public class Ejercicio15 {
  /**
   * Ocurrencias de c
   * TODO: Implementar usando recursividad.
   */
   public static int contarCaracter(String texto, char c) {
    if (texto == null) return 0;

    if (texto.isEmpty()) {
      return 0;
    }

    int suma = (texto.charAt(0) == c) ? 1 : 0;
    return suma + contarCaracter(texto.substring(1), c);
  }
}
