package com.docencia.logica;

public class Ejercicio17 {
  /**
   * ¿Ordenado asc?
   * TODO: Implementar usando lógica tradicional (iterativo).
   */
  public static boolean estaOrdenadoAsc(int[] arreglo) {
    if (arreglo == null) return true;

    for (int i = 0; i < arreglo.length - 1; i++) {
      if (arreglo[i] > arreglo[i + 1]) {
        return false; 
      }
    }

    return true;
  }
}
