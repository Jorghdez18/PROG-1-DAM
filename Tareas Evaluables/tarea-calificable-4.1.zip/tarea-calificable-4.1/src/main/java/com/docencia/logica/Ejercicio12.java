package com.docencia.logica;

public class Ejercicio12 {
  /**
   * Máximo elemento
   * TODO: Implementar usando lógica tradicional (iterativo).
   */
  public static int maximoArreglo(int[] arreglo) {
    if (arreglo == null){
      throw new IllegalArgumentException();
    }
    if (arreglo.length < 1){
      return 0;
    }
    int maximo = 0;
    for (int numero : arreglo) {
      if (maximo < numero) {
        maximo = numero;
      }
    }
    return maximo;
  }
}
