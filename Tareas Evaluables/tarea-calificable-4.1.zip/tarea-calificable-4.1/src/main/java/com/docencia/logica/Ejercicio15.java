package com.docencia.logica;

public class Ejercicio15 {
  /**
   * Ocurrencias de c
   * TODO: Implementar usando lógica tradicional (iterativo).
   */
 public static int contarCaracter(String texto, char c) {
    if (texto == null) return 0;

    int contador = 0;

    for (int i = 0; i < texto.length(); i++) {
      if (texto.charAt(i) == c) {
        contador++;
      }
    }

    return contador;
  }
}
