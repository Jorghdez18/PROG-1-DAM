package com.docencia.logica;

public class Ejercicio16 {
  /**
   * Elimina c
   * TODO: Implementar usando lógica tradicional (iterativo).
   */
 public static String eliminarCaracter(String texto, char c) {
    if (texto == null) return "";

    StringBuilder resultado = new StringBuilder();
    for (int i = 0; i < texto.length(); i++) {
      char ch = texto.charAt(i);
      if (ch != c) {
        resultado.append(ch);
      }
    }

    return resultado.toString();
  }
}
