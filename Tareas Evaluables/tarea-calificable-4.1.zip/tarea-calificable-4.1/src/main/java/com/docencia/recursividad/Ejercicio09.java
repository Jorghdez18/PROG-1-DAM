package com.docencia.recursividad;

public class Ejercicio09 {
  /**
   * Invierte número (sin String)
   * TODO: Implementar usando recursividad.
   */
   public static int invertirNumero(int n) {
        int signo = n < 0 ? -1 : 1;
        n = Math.abs(n);
        int len = com.docencia.logica.Ejercicio08.contarDigitos(n);
        return signo * inv(n, len);
    }

    private static int inv(int n, int len) {
        if (len == 1) {
            return n;
        }

        int ultimo = n % 10;
        int resto = n / 10;

        return (int) (ultimo * Math.pow(10, len - 1) + inv(resto, len - 1));
    }
}