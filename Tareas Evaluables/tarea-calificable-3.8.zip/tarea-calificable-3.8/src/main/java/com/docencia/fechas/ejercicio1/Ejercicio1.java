package com.docencia.fechas.ejercicio1;

import com.docencia.fechas.BusinessCalendar;

import java.time.LocalDate;
import java.util.Objects;
import java.util.regex.Pattern;

public final class Ejercicio1 {
    /**
     * POSIBE EJERCICIO PAL VIERNES, validar una fecha con un patron y luego dicha fecha
     * pasarla a un date para poder de nuevo compararla y ver si es fin de semana o 
     * laborable
     */

    private Ejercicio1() {}

    public static String labelDay(LocalDate date) {
        if (date == null ){
            throw new NullPointerException();
        }
        if(date.getDayOfWeek().getValue()> 5){
            return "FIN_DE_SEMANA";

        }
        return "LABORABLE";

    }
}
    /** 
    public static String labelDay (String date){
        if (date == null|| date.isBlank()){
            throw new IllegalArgumentException();
        }
        String patron ="\\d{2}-\\d{2}-\\d{4}";
        boolean esFecha = Pattern.matches( patron, date);
        if (!esFecha){
            throw new IllegalArgumentException();
        }
        String[] arrayFecha = date.split("-");
        LocalDate.of(2026, 02, 10);
        return null;

    }
}
    */