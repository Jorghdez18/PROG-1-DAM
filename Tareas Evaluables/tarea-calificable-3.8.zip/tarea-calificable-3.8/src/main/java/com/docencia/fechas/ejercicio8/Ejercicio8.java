package com.docencia.fechas.ejercicio8;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Objects;

public final class Ejercicio8 {

    private Ejercicio8() {}

    public static LocalDate processingDateByCutoff(LocalDateTime received, LocalTime cutoff) {
        if (received == null || cutoff == null){
            throw new NullPointerException();
        }
         if (received.toLocalTime().isAfter(cutoff)) {
            received = received.plusDays(1);
        }

        return received.toLocalDate();
    }
}
