package com.docencia.expresiones.ejercicio6;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Ejercicio6 {

    private Ejercicio6() {}

    public static LocalDateTime applyDeltaCommand(LocalDateTime base, String command) {
        if (base == null || command == null || command.isBlank()){
            throw new IllegalArgumentException();
        }
        String patron = "^(+[0-9][dh]|(-[0-9][dh])$";
         Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(command);

        if (!matcher.matches()) { 
            throw new IllegalArgumentException();
        }

        String fecha = matcher.group();
        return LocalDateTime.parse(fecha);
    }
}