package com.docencia.expresiones.ejercicio1;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Ejercicio1 {

    private Ejercicio1() {}

  

    public static LocalDate parseIsoDate(String input) {
        if (input == null || input.isBlank()) {
            throw new IllegalArgumentException();
        }
        String patron ="(\\d{2}-\\d{2}-\\d{4}|\\d{4}-\\d{2}-\\d{2})";
       
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(input);
        Pattern.matches(patron, input);
        
        if (!matcher.find()){
            throw new IllegalArgumentException();
        }
        String fecha = matcher.group(0);
        return LocalDate.parse(input);
    }
}
