package com.docencia.expresiones.ejercicio7;

import com.docencia.expresiones.DateRangeResult;
import com.docencia.fechas.BusinessCalendar;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Ejercicio7 {

    private Ejercicio7() {}


    public static DateRangeResult parseDateRange(String input) {
        if (input == null || input.isBlank()){
            throw new IllegalArgumentException();
        }
        String patron = "\\d{4}-\\d{2}-\\d{2}...\\d{4}-\\d{2}-\\d{2}";
       Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(input);

        if (!matcher.matches()) { 
            throw new IllegalArgumentException();
        }

        String fecha = matcher.group();

        return DateRangeResult.parseDateRange(fecha);
    }
}
