package com.docencia.expresiones.ejercicio8;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.w3c.dom.Text;

public final class Ejercicio8 {

    private Ejercicio8() {}


    public static Map<LocalDate, Long> countEventsByDay(String text) {
        if (text == null || text.isBlank()){
            throw new IllegalArgumentException();
        }
        String patron = "\\d{4}-\\d{2}-\\d{2}\\s\\d:\\d";
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(text);

        if (!matcher.matches()) { 
            throw new IllegalArgumentException();
        }

        String fecha = matcher.group();
        return null;
    }
}
