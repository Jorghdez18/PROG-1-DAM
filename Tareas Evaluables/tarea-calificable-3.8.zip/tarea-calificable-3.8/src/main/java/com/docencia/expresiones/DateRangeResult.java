package com.docencia.expresiones;

import java.time.LocalDate;

public record DateRangeResult(LocalDate start, LocalDate end, long totalDaysInclusive, int businessDaysInclusive) {

    public static DateRangeResult parseDateRange(String input) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'parseDateRange'");
    }}
