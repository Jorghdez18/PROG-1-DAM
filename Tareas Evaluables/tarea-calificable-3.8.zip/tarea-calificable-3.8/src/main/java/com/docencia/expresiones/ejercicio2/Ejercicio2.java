package com.docencia.expresiones.ejercicio2;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Ejercicio2 {

    private Ejercicio2() {}


    public static LocalTime extractFirstTime(String text) {
        if (text == null || text.isBlank()){
            throw new IllegalArgumentException();
        }
        String patron = "(0\\d|1\\d|2[0-3]):\\d{2}"; //"09:50  || 11:30  x 25:01"
        
        
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(text);
        Pattern.matches(patron, text);
        
        if (!matcher.find()){
            throw new IllegalArgumentException();
        }
        String fecha = matcher.group(0);
        return LocalTime.parse(fecha);
        //09:30 LocalTime.of // LocalTime.parse
    }
}
