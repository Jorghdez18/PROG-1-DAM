package com.docencia.fechas.ejercicio7;

import com.docencia.fechas.TimeUtils;

import java.time.LocalTime;

public final class Ejercicio7 {

    private Ejercicio7() {}

    public static boolean isOpenInclusive(LocalTime t, LocalTime open, LocalTime close) {

        if (t == null || close == null || open == null){
            throw new NullPointerException();
        }
        
       if (!open.isAfter(close)) {
            return !t.isBefore(open) && !t.isAfter(close);
        } else { 
            return !t.isBefore(open) || !t.isAfter(close);
        }
    }
}

