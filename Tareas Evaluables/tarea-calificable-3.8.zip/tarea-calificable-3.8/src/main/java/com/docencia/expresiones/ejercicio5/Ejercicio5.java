package com.docencia.expresiones.ejercicio5;

import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Ejercicio5 {

    private Ejercicio5() {}

    public static Instant parseLogInstant(String logLine) {
        if (logLine == null || logLine.isBlank()){
            throw new IllegalArgumentException();
        }
     
        String patron = "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}+00:00 user=\\d{2} action=[a-zA-Z]+";

        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(logLine);

         if (!matcher.matches()) {
            throw new IllegalArgumentException();
        }
        String fecha = matcher.group(0);

        return Instant.parse(fecha);

    }
}
