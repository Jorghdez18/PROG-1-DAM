package com.docencia.expresiones.ejercicio3;

import java.time.LocalDateTime;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Ejercicio3 {

    private Ejercicio3() {}

    public static LocalDateTime parseFlexibleLocalDateTime(String input) {
        if (input == null || input.isBlank()) {
            throw new IllegalArgumentException();
        }

        //String patron = "^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])(\\s|T)(0\\d|1\\d|2[0-3]):([0-5]\\d)$";
        String patron = "^\\d{4}-(0\\d|1[0-2])-(0\\d|[12]\\d|3[01])(\\s|T)([0-2]\\d):([0-5]\\d)$";


        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(input);

        if (!matcher.matches()) { 
            throw new IllegalArgumentException();
        }

        String fecha = matcher.group();

        /**
         * La clase solo aceptara el formato con la letra 't', entre fecha y hora, por lo que para permitir
         * ambos formatos, sustituimos el espacio por la 't', antes de parsear la fecha (el ejercicio se complico aun teniendo la 
         * expresion bien hecha, por lo que he recurrido a la ia, para que me explique el funcionamiento del test,
         *  por lo tanto con esa ayuda he llegado a la conclucion de como hacer el ejercicio) pd: perdon profe sera recompensado con sus milojas,
         * el ejercicio me lo tome  muy a lo personal, tenia que acabarlo si o si.
         */
        fecha = fecha.replace(' ', 'T'); 

        return LocalDateTime.parse(fecha);
    }
}