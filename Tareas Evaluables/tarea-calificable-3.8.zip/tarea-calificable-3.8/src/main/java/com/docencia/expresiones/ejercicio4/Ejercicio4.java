package com.docencia.expresiones.ejercicio4;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Ejercicio4 {

    private Ejercicio4() {}


    public static ZoneId parseZoneCommand(String input) {
        if (input == null || input.isBlank()){
            throw new IllegalArgumentException();
        }
        String patron = "^SET TZ=[A-Za-z]+/[A-Za-z]+$";
        
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(input);
        Pattern.matches(patron, input);
        
        if (!matcher.find()){
            throw new IllegalArgumentException();
        }
        String fecha = matcher.group(0);
        return null;
    }
}
