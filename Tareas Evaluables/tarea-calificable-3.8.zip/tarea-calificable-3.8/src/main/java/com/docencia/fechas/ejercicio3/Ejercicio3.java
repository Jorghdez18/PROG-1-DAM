package com.docencia.fechas.ejercicio3;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Objects;

public final class Ejercicio3 {

    private Ejercicio3() {}

    public static LocalDateTime buildAppointmentChecked(LocalDate date, LocalTime time, LocalDateTime now) {
        if (date == null || time == null || now == null){
            throw new NullPointerException();
        }
        LocalDateTime valido = LocalDateTime.of(date,time);
        if (valido.isBefore(now)){
            throw new IllegalArgumentException();
        }

        
         return valido;
    }


}
