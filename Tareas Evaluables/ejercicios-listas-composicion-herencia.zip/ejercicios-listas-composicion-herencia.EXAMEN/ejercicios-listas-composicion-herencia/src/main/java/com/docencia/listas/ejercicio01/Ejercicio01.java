package com.docencia.listas.ejercicio01;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class Ejercicio01 {

    private Ejercicio01() {
        // Utilidad estática
    }

    public static int maximo(List<Integer> numeros) {
        //return Collections.max(numeros); lo mismo pero en una línea
        if (numeros == null || numeros.isEmpty()){
            return -1;
        }
        int resultado = numeros.get(0);
        
        for (int i = 0; i < numeros.size(); i++) {
            if (resultado < numeros.get(i)){
                resultado = numeros.get(i);
            }
        }
        return resultado;
    }

    public static int minimo(List<Integer> numeros) {
        //return Collections.min(numeros);
        if (numeros == null || numeros.isEmpty()){
            return -1;
        }
        int resultado = numeros.get(0);
        
        for (int i = 0; i < numeros.size(); i++) {
            if (resultado > numeros.get(i)){
                resultado = numeros.get(i);
            }
        }
        return resultado;
    }
    public static void eliminarNegativos(List<Integer> numeros) {
        List <Integer> resultado = new ArrayList<>();
        /** dos maneras, una quedandote con ,los negtivos 
        for (Integer numero : resultado) {
            if ( numero >= 0){
                resultado.add(numero);
            }
            
        }
         numeros =resultado;
        */
       /**  eliminando los negativos de la list original
       for (Integer numero : resultado) {
            if ( numero < 0){
                numeros.remove(numero);
            }
            
        }
         numeros =resultado;
         */

         numeros.removeIf(numero -> numero < 0); //forma más corta
    }

}
