package com.docencia.listas.ejercicio05;

import java.util.Collections;
import java.util.List;

public class Ejercicio05 {

    private Ejercicio05() {
    }

    public static void invertir(List<String> lista) {
        Collections.reverse(lista);
        /** 
        Object[] arrayLista = lista.toArray();
        Object [] arrayResultado = new Object[arrayLista.length];
        for (int j = 0; j < arrayResultado.length; j++) {
        
        arrayResultado[arrayResultado.length-1-i] = arrayLista[i];
        }
        */
        
    }
}
