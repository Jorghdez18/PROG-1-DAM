package com.docencia.herencia.ejercicio22;

import java.util.ArrayList;
import java.util.List;

/**
 * Ejercicio 22 - ver la descripción detallada en el README.md.
 *
 * Diseña aquí la jerarquía de clases, clases base abstractas,
 * subclases concretas y métodos polimórficos correspondientes
 * al enunciado.
 */
public class Ejercicio22 {
}

