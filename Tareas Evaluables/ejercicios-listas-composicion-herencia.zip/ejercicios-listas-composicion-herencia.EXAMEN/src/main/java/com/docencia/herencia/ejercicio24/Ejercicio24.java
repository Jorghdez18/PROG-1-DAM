package com.docencia.herencia.ejercicio24;

/**
 * Ejercicio 24 - ver la descripción detallada en el README.md.
 *
 * Diseña aquí la jerarquía de clases, clases base abstractas,
 * subclases concretas y métodos polimórficos correspondientes
 * al enunciado.
 */
public class Ejercicio24 {
   public static void main(String[] args) {
    
        // Creamos cada notificación individualmente
        EmailNotificacion email = new EmailNotificacion("ana@mail.com", "Hola Ana");
        SMSNotificacion sms = new SMSNotificacion("hola que tal Jorge","660071190" ){};
        System.out.println(email);
        System.out.println(sms);
        //System.out.println(push);
   }
   
}
