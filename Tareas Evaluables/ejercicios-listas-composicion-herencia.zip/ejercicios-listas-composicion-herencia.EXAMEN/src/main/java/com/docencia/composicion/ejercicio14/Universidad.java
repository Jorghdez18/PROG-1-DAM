package com.docencia.composicion.ejercicio14;

import java.util.ArrayList;
import java.util.List;

public class Universidad {

    private ArrayList<Facultad> facultades;

    public Universidad() {
        this.facultades = new ArrayList<>();
    }

    public void agregarFacultad(Facultad f) {
        facultades.add(f);
    }

    public List<Estudiante> BuscarEstudiantePorId() {
        List<Estudiante> resultado = new ArrayList<>();

        for (Facultad f : facultades) {
            resultado.addAll(f.getEstudiantes());
        }
        return resultado;
    }

    public Estudiante buscarPorId(int id) {
        for (Facultad f : facultades) {
            for (Estudiante e : f.getEstudiantes()) {
                if (e.getId() == id) {
                    return e;
                }
            }
        }
        return null;
    }
}
