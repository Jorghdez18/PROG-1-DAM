package com.docencia.herencia.ejercicio25;
import java.util.Objects;

public class Vaca extends Animal{

    private int numUbres;
    private int numCuernos;


    public Vaca (){}

    public Vaca(String nombre){
        super(nombre);
        this.numCuernos = numCuernos;
        this.numUbres = numUbres;
    }


    public Vaca(int numUbres, int numCuernos) {
        this.numUbres = numUbres;
        this.numCuernos = numCuernos;
    }

    public int getNumUbres() {
        return this.numUbres;
    }

    public void setNumUbres(int numUbres) {
        this.numUbres = numUbres;
    }

    public int getNumCuernos() {
        return this.numCuernos;
    }

    public void setNumCuernos(int numCuernos) {
        this.numCuernos = numCuernos;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Vaca)) {
            return false;
        }
        Vaca vaca = (Vaca) o;
        return numUbres == vaca.numUbres && numCuernos == vaca.numCuernos;
    }

    @Override
    public int hashCode() {
        return Objects.hash(numUbres, numCuernos);
    }

    @Override
    public String toString() {
        return "{" +
            " numUbres='" + getNumUbres() + "'" +
            ", numCuernos='" + getNumCuernos() + "'" +
            "}";
    }
    
    @Override
    public String hacerSonido(){
        return "MUUUUUUUUUUUUUUUUU";
    }
}
