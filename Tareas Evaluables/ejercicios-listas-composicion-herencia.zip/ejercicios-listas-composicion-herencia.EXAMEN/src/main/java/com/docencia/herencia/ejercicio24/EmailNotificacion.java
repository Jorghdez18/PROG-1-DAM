package com.docencia.herencia.ejercicio24;
import java.util.Objects;

public class EmailNotificacion extends Notificacion{

    private String email;
    private String mensaje;

    public EmailNotificacion (){}

    public EmailNotificacion (String mensaje, String fechaEnvio, String envio){
        super (mensaje, fechaEnvio);
        this.email = email;
        this.mensaje = mensaje;
    }

    public EmailNotificacion(String email, String mensaje) {
        this.email = email;
        this.mensaje = mensaje;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMensaje() {
        return this.mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof EmailNotificacion)) {
            return false;
        }
        EmailNotificacion emailNotificacion = (EmailNotificacion) o;
        return Objects.equals(email, emailNotificacion.email) && Objects.equals(mensaje, emailNotificacion.mensaje);
    }

    @Override
    public int hashCode() {
        return Objects.hash(email, mensaje);
    }

    @Override
    public String toString() {
        return "{" +
            " email='" + getEmail() + "'" +
            ", mensaje='" + getMensaje() + "'" +
            "}";
    }

      @Override 
    public void enviar (){
        System.out.println("Enviado desde el email:" + email +"=" + mensaje);
    }



}
