package com.docencia.composicion.ejercicio13;
import java.util.Objects;

public class Libro {

    private String Titulo;
    private String autor;
    private int año;


    public Libro() {
    }

    public Libro(String titulo, String autor, int año) {
        this.Titulo = titulo;
        this.autor = autor;
        this.año = año;
    }

    public String getTitulo() {
        return this.Titulo;
    }

    public void setTitulo(String titulo) {
        this.Titulo = titulo;
    }

    public String getAutor() {
        return this.autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAño() {
        return this.año;
    }

    public void setAño(int año) {
        this.año = año;
    }
    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Libro)) {
            return false;
        }
        Libro libro = (Libro) o;
        return Objects.equals(Titulo, libro.Titulo) && Objects.equals(autor, libro.autor) && año == libro.año;
    }

    @Override
    public int hashCode() {
        return Objects.hash(Titulo, autor, año);
    }

    @Override
    public String toString() {
        return "{" +
            " titulo='" + getTitulo() + "'" +
            ", autor='" + getAutor() + "'" +
            ", año='" + getAño() + "'" +
            "}";
    }
    

}
