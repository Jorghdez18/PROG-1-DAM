package com.docencia.herencia.ejercicio24;
import java.util.Objects;

public abstract class Notificacion {

    private String mensaje; 
    private String fechaEnvio;

    public abstract void enviar();   


    public Notificacion() {}


    public Notificacion(String mensaje, String fechaEnvio) {
        this.mensaje = mensaje;
        this.fechaEnvio = fechaEnvio;
    }

    public String getMensaje() {
        return this.mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getFechaEnvio() {
        return this.fechaEnvio;
    }

    public void setFechaEnvio(String fechaEnvio) {
        this.fechaEnvio = fechaEnvio;
    }

    public Notificacion mensaje(String mensaje) {
        setMensaje(mensaje);
        return this;
    }

    public Notificacion fechaEnvio(String fechaEnvio) {
        setFechaEnvio(fechaEnvio);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Notificacion)) {
            return false;
        }
        Notificacion notificacion = (Notificacion) o;
        return Objects.equals(mensaje, notificacion.mensaje) && Objects.equals(fechaEnvio, notificacion.fechaEnvio);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mensaje, fechaEnvio);
    }

    @Override
    public String toString() {
        return "{" +
            " mensaje='" + getMensaje() + "'" +
            ", fechaEnvio='" + getFechaEnvio() + "'" +
            "}";
    }

}

   