package com.docencia.herencia.ejercicio25;
import java.util.Objects;

public class Perro extends Animal {

    private int numPatas;
    private String raza;

    public Perro(){}

    public Perro (String nombre){
        super(nombre);
        this.numPatas = numPatas;
        this.raza = raza;
    }

    public Perro(int numPatas, String raza) {
        this.numPatas = numPatas;
        this.raza = raza;
    }

    public int getNumPatas() {
        return this.numPatas;
    }

    public void setNumPatas(int numPatas) {
        this.numPatas = numPatas;
    }

    public String getRaza() {
        return this.raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Perro)) {
            return false;
        }
        Perro perro = (Perro) o;
        return numPatas == perro.numPatas && Objects.equals(raza, perro.raza);
    }

    @Override
    public int hashCode() {
        return Objects.hash(numPatas, raza);
    }

    @Override
    public String toString() {
        return "{" +
            " numPatas='" + getNumPatas() + "'" +
            ", raza='" + getRaza() + "'" +
            "}";
    }

    @Override 
    public String hacerSonido(){
       return "guau guau";
    }
    

}
