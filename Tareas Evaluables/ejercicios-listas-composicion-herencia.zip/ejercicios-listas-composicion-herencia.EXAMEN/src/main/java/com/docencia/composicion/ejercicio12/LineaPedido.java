package com.docencia.composicion.ejercicio12;
import java.util.Objects;

public class LineaPedido {

    private String pedido;
    private int cantidad;


    public LineaPedido() {
    }

    public LineaPedido(String pedido, int cantidad) {
        this.pedido = pedido;
        this.cantidad = cantidad;
    }

    public String getPedido() {
        return this.pedido;
    }

    public void setPedido(String pedido) {
        this.pedido = pedido;
    }

    public int getCantidad() {
        return this.cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof LineaPedido)) {
            return false;
        }
        LineaPedido lineaPedido = (LineaPedido) o;
        return Objects.equals(pedido, lineaPedido.pedido) && cantidad == lineaPedido.cantidad;
    }

    @Override
    public int hashCode() {
        return Objects.hash(pedido, cantidad);
    }

    @Override
    public String toString() {
        return "{" +
            " pedido='" + getPedido() + "'" +
            ", cantidad='" + getCantidad() + "'" +
            "}";
    }

    public double calcularSubtotal() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'calcularSubtotal'");
    }
    

}
