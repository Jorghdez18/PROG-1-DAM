package com.docencia.composicion.ejercicio11;
import java.util.Objects;

public class Direccion {

    private String calle;
    private String ciudad;
    private int codigoPostal;


    public Direccion() {
    }

    public Direccion(String calle, String ciudad, int codigoPostal) {
        this.calle = calle;
        this.ciudad = ciudad;
        this.codigoPostal = codigoPostal;
    }

    public String getCalle() {
        return this.calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getCiudad() {
        return this.ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public int getCodigoPostal() {
        return this.codigoPostal;
    }

    public void setCodigoPostal(int codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Direccion)) {
            return false;
        }
        Direccion direccion = (Direccion) o;
        return Objects.equals(calle, direccion.calle) && Objects.equals(ciudad, direccion.ciudad) && codigoPostal == direccion.codigoPostal;
    }

    @Override
    public int hashCode() {
        return Objects.hash(calle, ciudad, codigoPostal);
    }

    @Override
    public String toString() {
        return "{" +
            " calle='" + getCalle() + "'" +
            ", ciudad='" + getCiudad() + "'" +
            ", codigoPostal='" + getCodigoPostal() + "'" +
            "}";
    }

}
