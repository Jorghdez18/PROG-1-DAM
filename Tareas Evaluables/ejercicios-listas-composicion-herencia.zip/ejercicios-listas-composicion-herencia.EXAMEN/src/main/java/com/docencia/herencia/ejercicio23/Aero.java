package com.docencia.herencia.ejercicio23;

public class Aero extends Vehiculo {

    final int alas;

    public Aero() {
        alas = 2;
    }

    public Aero(int alas, String matricula) {
        super(matricula);
        this.alas = alas;
    }

    public Aero (int alas, String matricula, String modelo) {
        super(matricula, null, modelo);
        this.alas = alas;
        
    }

    public Aero(String matricula, String marca, String modelo) {
        super(matricula, marca, modelo);
        this.alas = 2;
    }

    public Aero(int alas, String matricula,
            String marca, String modelo) {
        super(matricula, marca, modelo);
        this.alas = alas;
    }

    @Override
    String descripcion() {
        return "No se como pero vuelo";
    }

    @Override
    public String toString() {
        return "Avion:" + super.toString();
    }

}
