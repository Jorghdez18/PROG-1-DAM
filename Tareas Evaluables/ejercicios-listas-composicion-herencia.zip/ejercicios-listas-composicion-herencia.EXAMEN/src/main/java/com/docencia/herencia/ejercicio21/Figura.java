package com.docencia.herencia.ejercicio21;

public abstract class Figura {
    private long base;
    private long altura;

    public Figura() {}

    public Figura (long base, long altura) {
        this.base = base;
        this.altura = altura;
    }
    /**
     * Funcion que calcula el area de la figura
     * @return double con el valor obtenido
     */
    public double area() {
        return base * altura;
    }
}
