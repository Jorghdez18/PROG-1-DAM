package com.docencia.herencia.ejercicio25;
import java.util.Objects;

public class Gato extends Animal {

    private int numeroPatas;
    private int numBigote;

    public Gato(){}

    public Gato(String nombre){
        super(nombre);
        this.numeroPatas = numeroPatas;
        this.numBigote = numBigote;
    }


    public Gato(int numeroPatas, int numBigote) {
        this.numeroPatas = numeroPatas;
        this.numBigote = numBigote;
    }

    public int getNumeroPatas() {
        return this.numeroPatas;
    }

    public void setNumeroPatas(int numeroPatas) {
        this.numeroPatas = numeroPatas;
    }

    public int getNumBigote() {
        return this.numBigote;
    }

    public void setNumBigote(int numBigote) {
        this.numBigote = numBigote;
    }



    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Gato)) {
            return false;
        }
        Gato gato = (Gato) o;
        return numeroPatas == gato.numeroPatas && numBigote == gato.numBigote;
    }

    @Override
    public int hashCode() {
        return Objects.hash(numeroPatas, numBigote);
    }

    @Override
    public String toString() {
        return "{" +
            " numeroPatas='" + getNumeroPatas() + "'" +
            ", numBigote='" + getNumBigote() + "'" +
            "}";
    }
    
    @Override 
    public String hacerSonido(){
       return "miau miau";
    }
}
