package com.docencia.composicion.ejercicio14;

import java.util.ArrayList;
import java.util.List;

import com.docencia.composicion.ejercicio13.Libro;

public class Facultad {

     private List<Estudiante> estudiantes;

       public Facultad() { //constructor "vacio"
        this.estudiantes = new ArrayList<>();
    }
      public void agregarEstudiante(Estudiante e) {
        estudiantes.add(e);
    }

    public List<Estudiante> getEstudiantes() {
        return estudiantes;
    }
}
