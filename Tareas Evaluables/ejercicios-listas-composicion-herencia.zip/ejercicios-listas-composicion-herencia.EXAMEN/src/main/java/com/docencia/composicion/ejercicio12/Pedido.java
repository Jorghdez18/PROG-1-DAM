package com.docencia.composicion.ejercicio12;

import java.util.ArrayList;
import java.util.Objects;

public class Pedido {

       private ArrayList<LineaPedido> lineas;

       public Pedido() {
        this.lineas = new ArrayList<>();
    }

    public void añadirLinea(LineaPedido linea) {
        lineas.add(linea);
    }

    public double calcularTotal() {
        double total = 0;

        for (LineaPedido linea : lineas) {
            total += linea.calcularSubtotal();
        }

        return total;
    }

    public double calcularTotalConDescuento(double descuento) {
        double total = calcularTotal();
        double rebaja = total * (descuento / 100);
        return total - rebaja;
    }
}