package com.docencia.herencia.ejercicio21;

public class Rectangulo extends Figura{
    public Rectangulo (long base, long alura) {
        super(base, alura);
    }
}
