package com.docencia.herencia.ejercicio22;
import java.util.Objects;

public abstract class Empleado {
    
    private String nombre;
    private String puesto;
    private double sueldo;


    public Empleado (){}


    public Empleado(String nombre, String puesto, double sueldo) {
        this.nombre = nombre;
        this.puesto = puesto;
        this.sueldo = sueldo;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPuesto() {
        return this.puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public double getSueldo() {
        return this.sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Empleado)) {
            return false;
        }
        Empleado empleado = (Empleado) o;
        return Objects.equals(nombre, empleado.nombre) && Objects.equals(puesto, empleado.puesto) && sueldo == empleado.sueldo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, puesto, sueldo);
    }

    @Override
    public String toString() {
        return "{" +
            " nombre='" + getNombre() + "'" +
            ", puesto='" + getPuesto() + "'" +
            ", sueldo='" + getSueldo() + "'" +
            "}";
    }
    
    public abstract double calcularSueldo();


}
