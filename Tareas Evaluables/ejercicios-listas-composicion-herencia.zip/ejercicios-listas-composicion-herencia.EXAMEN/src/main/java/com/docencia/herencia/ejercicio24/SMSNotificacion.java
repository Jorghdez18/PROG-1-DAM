package com.docencia.herencia.ejercicio24;
import java.util.Objects;

public abstract class SMSNotificacion extends Notificacion{

    private String mensaje;
    private String telefono;

    public SMSNotificacion (){}

    public SMSNotificacion (String mensaje, String fechaEnvio){
        super(mensaje, fechaEnvio);
        this.mensaje = mensaje;
        this.telefono = telefono;
    } 


    public String getMensaje() {
        return this.mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getTelefono() {
        return this.telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    
    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof SMSNotificacion)) {
            return false;
        }
        SMSNotificacion sMSNotificacion = (SMSNotificacion) o;
        return Objects.equals(mensaje, sMSNotificacion.mensaje) && Objects.equals(telefono, sMSNotificacion.telefono);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mensaje, telefono);
    }

    @Override
    public String toString() {
        return "{" +
            " mensaje='" + getMensaje() + "'" +
            ", telefono='" + getTelefono() + "'" +
            "}";
    }
    @Override 
    public void enviar() {
        System.out.println("El telefono: " +telefono+"te ha enviado el siguiente mensaje:"+ mensaje);
    }

}
