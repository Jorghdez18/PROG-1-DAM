package com.docencia.listas.ejercicio01;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Ejercicio01 {

    private Ejercicio01() {
        // Utilidad estática
    }

    public static int maximo(List<Integer> numeros) {

        return Collections.max(numeros);
        /**
         * if (numeros == null || numeros.isEmpty()) {
         * return -1;
         * }
         * int resultado = numeros.get(0);
         * 
         * for (int i = 1; i < numeros.size(); i++) {
         * if (resultado < numeros.get(i)) {
         * resultado = numeros.get(i);
         * }
         * }
         * return resultado;
         */
    }

    public static int minimo(List<Integer> numeros) {
        return Collections.min(numeros);
        /*
         * if (numeros == null || numeros.isEmpty()) {
         * return -1;
         * }
         * int resultado = numeros.get(0);
         * 
         * for (int i = 1; i < numeros.size(); i++) {
         * if (resultado > numeros.get(i)) {
         * resultado = numeros.get(i);
         * }
         * }
         * return resultado;
         */
    }

    public static void eliminarNegativos(List<Integer> numeros) {

        /**
         * List<Integer> resultado = new ArrayList<>();
         * 
         * for (Integer numero : numeros) {
         * if (numero >= 0) {
         * resultado.add(numero);
         * }
         * }
         * numeros = resultado;
         */
        for (int i = 0; i < numeros.size(); i++) {
            if (numeros.get(i) < 0 ) {
                Integer numero = numeros.get(i);
                numeros.remove(numero);
            }
        }
        //numeros.removeIf(numero -> numero < 0);
    }
}
