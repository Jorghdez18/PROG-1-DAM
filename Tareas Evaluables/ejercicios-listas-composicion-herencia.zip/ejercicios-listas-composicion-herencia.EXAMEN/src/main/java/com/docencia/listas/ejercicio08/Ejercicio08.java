package com.docencia.listas.ejercicio08;

import java.util.ArrayList;
import java.util.List;

public class Ejercicio08 {

    private Ejercicio08() {
    }

    public static class ResultadoParticion {
        private final List<Integer> pares;
        private final List<Integer> impares;

        public ResultadoParticion(List<Integer> pares, List<Integer> impares) {
            this.pares = pares;
            this.impares = impares;
        }

        public List<Integer> getPares() {
            return pares;
        }

        public List<Integer> getImpares() {
            return impares;
        }
    }

    public static ResultadoParticion partir(List<Integer> lista) {
           List<Integer> pares = new ArrayList<>();
            List<Integer> impares = new ArrayList<>();

            for (Integer n : lista) {
            if (n % 2 == 0) {
                pares.add(n);
            } else {
                impares.add(n);
            }
        }
        return new ResultadoParticion(pares, impares);

        
    }
}
    
