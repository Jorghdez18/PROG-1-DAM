package com.docencia.composicion.ejercicio16;

import java.util.ArrayList;

public class Contacto {

    private String nombre;
    private ArrayList <Telefono> listaTelefonos;

    public Contacto (){}

    



}
