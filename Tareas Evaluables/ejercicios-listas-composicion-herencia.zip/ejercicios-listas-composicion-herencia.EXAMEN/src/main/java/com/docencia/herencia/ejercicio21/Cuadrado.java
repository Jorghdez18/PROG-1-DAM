package com.docencia.herencia.ejercicio21;

public class Cuadrado extends Figura{

    public Cuadrado (long lado) {
        super(lado, lado);
    }
}
