package com.docencia.listas.ejercicio09;

import java.util.ArrayList;
import java.util.List;

public class Ejercicio09 {

    private Ejercicio09() {
    }

    public static List<String> pagina(List<String> elementos, int numeroPagina, int tamanoPagina) {
          // Calculamos el índice de inicio
        int inicio = (numeroPagina - 1) * tamanoPagina;
        // Calculamos el índice de fin (no inclusive)
        int fin = Math.min(inicio + tamanoPagina, elementos.size());

        // Si el índice de inicio es mayor o igual que el tamaño de la lista, devolvemos lista vacía
        if (inicio >= elementos.size() || inicio < 0) {
            return new ArrayList<>();
        }

        // Devolvemos la sublista correspondiente
        return elementos.subList(inicio, fin);
    }

    
}
    

