package com.docencia.herencia.ejercicio24;
import java.util.Objects;

public abstract class PushNotificacion extends Notificacion {

    private String dispositivo;
    private String mensaje;

    public PushNotificacion (){
    }
    
    public PushNotificacion(String mensaje, String fechaEnvio){
        super(mensaje, fechaEnvio);
        this.dispositivo = dispositivo;
        this.mensaje = mensaje;
    }

    public String getDispositivo() {
        return this.dispositivo;
    }

    public void setDispositivo(String dispositivo) {
        this.dispositivo = dispositivo;
    }

    public String getMensaje() {
        return this.mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public PushNotificacion dispositivo(String dispositivo) {
        setDispositivo(dispositivo);
        return this;
    }

    public PushNotificacion mensaje(String mensaje) {
        setMensaje(mensaje);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof PushNotificacion)) {
            return false;
        }
        PushNotificacion pushNotificacion = (PushNotificacion) o;
        return Objects.equals(dispositivo, pushNotificacion.dispositivo) && Objects.equals(mensaje, pushNotificacion.mensaje);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dispositivo, mensaje);
    }

    @Override
    public String toString() {
        return "{" +
            " dispositivo='" + getDispositivo() + "'" +
            ", mensaje='" + getMensaje() + "'" +
            "}";
    }
    
    @Override 
    public void enviar (){
        System.out.println("El dispositivo: " + dispositivo+"te ha enviado una notificacion de push, con el siguiente mensaje :" +mensaje);
    }

}
