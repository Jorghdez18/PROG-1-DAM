package com.docencia.herencia.ejercicio22;
import java.util.Objects;

public class EmpleadoPorHoras extends Empleado{

   private int horasTrabajadas;
   private double precioPorHoras;

   public EmpleadoPorHoras (){}

   public EmpleadoPorHoras (String nombre, String puesto, double sueldo){
    super(nombre, puesto, sueldo);
    this.horasTrabajadas = horasTrabajadas;
    this.precioPorHoras = precioPorHoras;
   }

    public EmpleadoPorHoras(int horasTrabajadas, double precioPorHoras) {
        this.horasTrabajadas = horasTrabajadas;
        this.precioPorHoras = precioPorHoras;
    }

    public int getHorasTrabajadas() {
        return this.horasTrabajadas;
    }

    public void setHorasTrabajadas(int horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }

    public double getPrecioPorHoras() {
        return this.precioPorHoras;
    }

    public void setPrecioPorHoras(double precioPorHoras) {
        this.precioPorHoras = precioPorHoras;
    }


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof EmpleadoPorHoras)) {
            return false;
        }
        EmpleadoPorHoras empleadoPorHoras = (EmpleadoPorHoras) o;
        return horasTrabajadas == empleadoPorHoras.horasTrabajadas && precioPorHoras == empleadoPorHoras.precioPorHoras;
    }

    @Override
    public int hashCode() {
        return Objects.hash(horasTrabajadas, precioPorHoras);
    }

    @Override
    public String toString() {
        return "{" +
            " horasTrabajadas='" + getHorasTrabajadas() + "'" +
            ", precioPorHoras='" + getPrecioPorHoras() + "'" +
            "}";
    }

    @Override 
    public double calcularSueldo(){
        return horasTrabajadas * precioPorHoras;
    }

}
