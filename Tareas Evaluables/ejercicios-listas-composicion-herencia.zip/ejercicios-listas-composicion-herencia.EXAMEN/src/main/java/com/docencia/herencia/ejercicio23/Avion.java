package com.docencia.herencia.ejercicio23;

public class Avion extends Aero {

    public Avion() {
        super(3, "1111");
    }

    public Avion(int alas, String matricula) {
        super(alas, matricula);

    }

    public Avion(int alas, String matricula, String modelo) {
        super(alas, matricula);

    }

    public Avion(int alas, String matricula,
            String marca, String modelo) {
        super(alas, matricula, marca, modelo);
    }

}
