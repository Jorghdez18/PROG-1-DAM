package com.docencia.composicion.ejercicio20;
import java.util.Objects;

public class Mascota {

    private String especie;
    private String nombre;

    public Mascota() {
    }

    public Mascota(String especie, String nombre) {
        this.especie = especie;
        this.nombre = nombre;
    }

    public String getEspecie() {
        return this.especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Mascota)) {
            return false;
        }
        Mascota mascota = (Mascota) o;
        return Objects.equals(especie, mascota.especie) && Objects.equals(nombre, mascota.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(especie, nombre);
    }

    @Override
    public String toString() {
        return "{" +
            " especie='" + getEspecie() + "'" +
            ", nombre='" + getNombre() + "'" +
            "}";
    }
}
