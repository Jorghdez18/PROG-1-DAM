package com.docencia.composicion.ejercicio11;

import java.util.ArrayList;
import java.util.List;

/**
 * Ejercicio 11 - ver la descripción detallada en el README.md.
 *
 * Diseña aquí las clases de dominio, atributos, métodos y relaciones
 * de composición correspondientes al enunciado.
 */
public class Ejercicio11 {
    public static void main(String[] args) {

        Direccion direccion1 = new Direccion("Una calle", "Una ciudad", 38000);
        Direccion direccion2 = new Direccion("Una calle", "Otra cidudad", 38000);

        Persona persona1 = new Persona("Un nombre", 17, direccion1);
        Persona persona2 = new Persona("Un otro nombre", 18, direccion2);
        Persona persona3 = new Persona("Un otro nombre", 19, direccion1);

        List<Persona> personas = new ArrayList<>();
        personas.add(persona1);
        personas.add(persona2);
        personas.add(persona3);

        /**
        Persona personaEncontrada = encontrarPersonaPorCiudad(personas,
                "Otra cidudad");

        System.out.println(personaEncontrada);
         */
        List<Persona> personasEncontradas = encontrarPersonasPorCiudad(personas, "Una ciudad");
        System.out.println(personasEncontradas);
    }

    public static Persona encontrarPersonaPorCiudad(List<Persona> personas, String ciudad) {
        if (personas == null || ciudad == null || ciudad.isBlank()) {
            return null;
        }

        for (Persona persona : personas) {
            if (persona.getDireccion() != null &&
                    persona.getDireccion().getCiudad() != null
                    && persona.getDireccion().getCiudad().equals(ciudad)) {
                return persona;
            }
        }

        return null;
    }

    public static List<Persona> encontrarPersonasPorCiudad(List<Persona> personas,
            String ciudad) {
        List<Persona> personasEncontradas = new ArrayList<>();

        if (personas == null || ciudad == null || ciudad.isBlank()) {
            return null;
        }

        for (Persona persona : personas) {
            if (persona.getDireccion() != null &&
                    persona.getDireccion().getCiudad() != null
                    && persona.getDireccion().getCiudad().equals(ciudad)) {
                personasEncontradas.add(persona);
            }
        }

        return personasEncontradas;
    }
}
