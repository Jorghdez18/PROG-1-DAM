package com.docencia.listas.ejercicio10;

import java.util.List;

public class Ejercicio10 {

    private Ejercicio10() {
    }

    public static void rotar(List<Integer> lista, int k) {
        int n = lista.size();
        if (n == 0) return; // lista vacía, nada que hacer

        // Normalizar k si es mayor que el tamaño de la lista
        k = k % n;
        if (k < 0) {
            k += n; // permitir k negativo (rotación a la izquierda)
        }

        // Rotar k veces
        for (int i = 0; i < k; i++) {
            // Sacamos el último elemento
            Integer ultimo = lista.remove(n - 1);
            // Lo insertamos al principio
            lista.add(0, ultimo);
        }
    }
    }

