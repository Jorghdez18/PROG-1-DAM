package com.docencia.herencia.ejercicio22;
import java.util.Objects;

public class EmpleadoFijo extends Empleado {

    private double sueldoMensual;

    public EmpleadoFijo (){}

    public EmpleadoFijo (String nombre, String puesto, double sueldo){
        super (nombre, puesto, 0);
        this.sueldoMensual = sueldoMensual;
    }


    public EmpleadoFijo(double sueldoMensual) {
        this.sueldoMensual = sueldoMensual;
    }

    public double getSueldoMensual() {
        return this.sueldoMensual;
    }

    public void setSueldoMensual(double sueldoMensual) {
        this.sueldoMensual = sueldoMensual;
    }

    public EmpleadoFijo sueldoMensual(double sueldoMensual) {
        setSueldoMensual(sueldoMensual);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof EmpleadoFijo)) {
            return false;
        }
        EmpleadoFijo empleadoFijo = (EmpleadoFijo) o;
        return sueldoMensual == empleadoFijo.sueldoMensual;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), sueldoMensual);    
    }

    @Override
    public String toString() {
        return "{" +
            " sueldoMensual='" + getSueldoMensual() + "'" +
            "}";
    }

    @Override 
    public  double calcularSueldo (){
        return sueldoMensual;
    }

    
}
