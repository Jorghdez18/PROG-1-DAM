package com.docencia.composicion.ejercicio16;
import java.util.Objects;

public class Telefono {

    private String tipo;
    private String numero;


    public Telefono() {
    }

    public Telefono(String tipo, String numero) {
        this.tipo = tipo;
        this.numero = numero;
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNumero() {
        return this.numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Telefono)) {
            return false;
        }
        Telefono telefono = (Telefono) o;
        return Objects.equals(tipo, telefono.tipo) && Objects.equals(numero, telefono.numero);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tipo, numero);
    }

    @Override
    public String toString() {
        return "{" +
            " tipo='" + getTipo() + "'" +
            ", numero='" + getNumero() + "'" +
            "}";
    }
    
}
